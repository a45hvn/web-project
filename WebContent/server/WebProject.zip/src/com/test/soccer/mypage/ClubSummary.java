package com.test.soccer.mypage;

public class ClubSummary {

}
