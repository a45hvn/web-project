package com.test.soccer.mypage;

public class Friends {

}
