package com.test.soccer.team;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/team/teamrecord.do")
public class TeamRecord extends HttpServlet{

}
