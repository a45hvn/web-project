package com.test.soccer.mypage;

public class RankDTO {
	
	private String sumrecord;
	private String ranking1;
	private String ranking2;
	private String ranking3;
	private String seq;
	
	public String getSumrecord() {
		return sumrecord;
	}
	public void setSumrecord(String sumrecord) {
		this.sumrecord = sumrecord;
	}
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getRanking1() {
		return ranking1;
	}
	public void setRanking1(String ranking1) {
		this.ranking1 = ranking1;
	}
	public String getRanking2() {
		return ranking2;
	}
	public void setRanking2(String ranking2) {
		this.ranking2 = ranking2;
	}
	public String getRanking3() {
		return ranking3;
	}
	public void setRanking3(String ranking3) {
		this.ranking3 = ranking3;
	}
	
	
	
}
