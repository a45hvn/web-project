package com.test.soccer.mypage;

public class FriendsDTO {

	private String seq;
	private String follower_seq;
	private String followerName;
	private String followerImage;
	private String following_seq;
	private String followingName;
	private String followingImage;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getFollower_seq() {
		return follower_seq;
	}
	public void setFollower_seq(String follower_seq) {
		this.follower_seq = follower_seq;
	}
	public String getFollowerName() {
		return followerName;
	}
	public void setFollowerName(String followerName) {
		this.followerName = followerName;
	}
	public String getFollowerImage() {
		return followerImage;
	}
	public void setFollowerImage(String followerImage) {
		this.followerImage = followerImage;
	}
	public String getFollowing_seq() {
		return following_seq;
	}
	public void setFollowing_seq(String following_seq) {
		this.following_seq = following_seq;
	}
	public String getFollowingName() {
		return followingName;
	}
	public void setFollowingName(String followingName) {
		this.followingName = followingName;
	}
	public String getFollowingImage() {
		return followingImage;
	}
	public void setFollowingImage(String followingImage) {
		this.followingImage = followingImage;
	}
	
	
	
	
}
