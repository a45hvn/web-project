package com.test.soccer.board;

public class formationDTO {

	private String seq;
	private String formation;
	private String position_x;
	private String position_y;
	private String team_seq;
	private String member_seq;
	private String position_seq;
	
	private String position;
	private String backnumber;
	private String name;
	
	private String image;
	
	private String entry_seq;
	
	public String getEntry_seq() {
		return entry_seq;
	}
	public void setEntry_seq(String entry_seq) {
		this.entry_seq = entry_seq;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	private String old;	
	public String getBacknumber() {
		return backnumber;
	}
	public void setBacknumber(String backnumber) {
		this.backnumber = backnumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOld() {
		return old;
	}
	public void setOld(String old) {
		this.old = old;
	}
	public String getPosition_seq() {
		return position_seq;
	}
	public void setPosition_seq(String position_seq) {
		this.position_seq = position_seq;
	}
	public String getMember_seq() {
		return member_seq;
	}
	public void setMember_seq(String member_seq) {
		this.member_seq = member_seq;
	}
	public String getTeam_seq() {
		return team_seq;
	}
	public void setTeam_seq(String team_seq) {
		this.team_seq = team_seq;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getFormation() {
		return formation;
	}
	public void setFormation(String formation) {
		this.formation = formation;
	}
	public String getPosition_x() {
		return position_x;
	}
	public void setPosition_x(String position_x) {
		this.position_x = position_x;
	}
	public String getPosition_y() {
		return position_y;
	}
	public void setPosition_y(String position_y) {
		this.position_y = position_y;
	}
	
	
	
	
}
