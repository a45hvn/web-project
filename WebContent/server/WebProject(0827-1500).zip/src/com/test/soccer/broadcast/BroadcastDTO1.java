package com.test.soccer.broadcast;

public class BroadcastDTO1 {
	
	private String seq;
	private String time;
	private String broadcastAct_seq;
	private String leagueGame_seq;
	private String playerEntry_seq;
	private String shortCout;
	private String event;
	private String playerName;
	private String team;
	private String rownum;
	private String league;
	private String leaguegame_seq;
	private String ground;
	private String homeTeam;
	private String awayTeam;
	private String winTeam;
	private String gamedate;
	private String homeGoal;
	private String awayGoal;
	private String homeTeam_seq;
	private String awayTeam_seq;
	private String league_seq;
	
	
	public String getHomeTeam_seq() {
		return homeTeam_seq;
	}
	public void setHomeTeam_seq(String homeTeam_seq) {
		this.homeTeam_seq = homeTeam_seq;
	}
	public String getAwayTeam_seq() {
		return awayTeam_seq;
	}
	public void setAwayTeam_seq(String awayTeam_seq) {
		this.awayTeam_seq = awayTeam_seq;
	}
	public String getLeague_seq() {
		return league_seq;
	}
	public void setLeague_seq(String league_seq) {
		this.league_seq = league_seq;
	}
	public String getRownum() {
		return rownum;
	}
	public void setRownum(String rownum) {
		this.rownum = rownum;
	}
	public String getLeague() {
		return league;
	}
	public void setLeague(String league) {
		this.league = league;
	}
	public String getLeaguegame_seq() {
		return leaguegame_seq;
	}
	public void setLeaguegame_seq(String leaguegame_seq) {
		this.leaguegame_seq = leaguegame_seq;
	}
	public String getGround() {
		return ground;
	}
	public void setGround(String ground) {
		this.ground = ground;
	}
	public String getHomeTeam() {
		return homeTeam;
	}
	public void setHomeTeam(String homeTeam) {
		this.homeTeam = homeTeam;
	}
	public String getAwayTeam() {
		return awayTeam;
	}
	public void setAwayTeam(String awayTeam) {
		this.awayTeam = awayTeam;
	}
	public String getWinTeam() {
		return winTeam;
	}
	public void setWinTeam(String winTeam) {
		this.winTeam = winTeam;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getBroadcastAct_seq() {
		return broadcastAct_seq;
	}
	public void setBroadcastAct_seq(String broadcastAct_seq) {
		this.broadcastAct_seq = broadcastAct_seq;
	}
	public String getLeagueGame_seq() {
		return leagueGame_seq;
	}
	public void setLeagueGame_seq(String leagueGame_seq) {
		this.leagueGame_seq = leagueGame_seq;
	}
	public String getPlayerEntry_seq() {
		return playerEntry_seq;
	}
	public void setPlayerEntry_seq(String playerEntry_seq) {
		this.playerEntry_seq = playerEntry_seq;
	}
	public String getShortCout() {
		return shortCout;
	}
	public void setShortCout(String shortCout) {
		this.shortCout = shortCout;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getGamedate() {
		return gamedate;
	}
	public void setGamedate(String gamedate) {
		this.gamedate = gamedate;
	}
	public String getHomeGoal() {
		return homeGoal;
	}
	public void setHomeGoal(String homeGoal) {
		this.homeGoal = homeGoal;
	}
	public String getAwayGoal() {
		return awayGoal;
	}
	public void setAwayGoal(String awayGoal) {
		this.awayGoal = awayGoal;
	}
	
	
}
